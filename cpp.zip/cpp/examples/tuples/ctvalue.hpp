template<typename T, T Value>
struct CTValue
{ 
  static constexpr T value = Value;
};
