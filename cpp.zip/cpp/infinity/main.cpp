#include <iostream>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	true;
	double infinity = 1.0/0.0;
	cout << 100000 * infinity << endl;
	return 0;
}
