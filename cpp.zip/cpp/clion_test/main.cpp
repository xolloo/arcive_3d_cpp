#include <iostream>
#include <gtkmm/window.h>

int main() {
    std::cout << "Hello, World!" << std::endl;
    return 0;
}
