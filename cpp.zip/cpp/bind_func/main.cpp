#include <iostream>
#include <functional>
#include <cmath>

int sum(int lhs, int rhs) {
    return lhs + rhs;
}

struct A {
    static void print() {
        std::cout << "A::print() " << "\n";
    }
};
template<class T>
T func(T a, T b, T c) {
    return pow((a * b), c);
}

int map(std::function<T(int, int)> f, int a, int b) {
    return f(a, b);
}

int main() {
    //    auto f_sum = [](auto &&, auto &&PH2) { return sum(3, std::forward<decltype(PH2)>(PH2)); };
    auto f_sum = std::bind(sum, 3, std::placeholders::_2);
    std::cout << f_sum(5, 2) << '\n';

    /*A a;
    auto f = std::bind(&A::print, a);
    f();*/

    /*auto third = std::bind(func, std::placeholders::_1, std::placeholders::_2, 3);
    std::cout << func(3, 4, 2) << " | " << third(1, 3) << '\n';*/

    std::cout
        << map(
            static_cast<std::function<int(int, int)>>(std::bind(
                func, std::placeholders::_1, std::placeholders::_2, 3)), 4, 7)
        << std::endl;
    return 0;
}
