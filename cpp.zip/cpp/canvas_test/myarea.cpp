#include "myarea.h"

MyArea::MyArea()
: m_fix (0)
{
  set_size_request (200, 100);
}

MyArea::~MyArea()
{
}

bool MyArea::on_draw(const Cairo::RefPtr<Cairo::Context>& cr)
{
  Gtk::Allocation allocation = get_allocation();
  const int width = allocation.get_width();
  const int height = allocation.get_height();

  cr->set_line_width(1.0);

  // рисовать одну линию через каждые два пикселя
  // без этого "исправления" вы не заметите пространства между линиями
  // так как каждая из линий будет занимать по два пикселя (в ширину)
  for (int i = 0; i < width; i += 2)
  {
	cr->move_to(i + m_fix, 0);
	cr->line_to(i + m_fix, height);
  }

  cr->stroke();

  return true;
}

// Переключение между значениями (0 или 0.5)
void MyArea::fix_lines(bool fix)
{
  // для получения корректной ширины линии нам придется рисовать из середины каждого из пикселей
  m_fix = fix ? 0.5 : 0.0;

  force_redraw();
}

// принудительная перерисовка изображения
void MyArea::force_redraw()
{
  Glib::RefPtr<Gdk::Window> win = get_window();
  if (win)
  {
	Gdk::Rectangle r(0, 0, get_allocation().get_width(), get_allocation().get_height());
	win->invalidate_rect(r, false);
  }
}

