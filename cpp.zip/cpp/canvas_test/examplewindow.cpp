#include "examplewindow.h"

ExampleWindow::ExampleWindow()
: m_Button_FixLines("Исправить линии")
{
  set_title("Пример рисования тонких линий");

  m_Container.set_orientation(Gtk::ORIENTATION_HORIZONTAL);

  m_Container.add(m_Area_Lines);
  m_Container.add(m_Button_FixLines);

  add(m_Container);

  m_Button_FixLines.signal_toggled().connect(
	sigc::mem_fun(*this, &ExampleWindow::on_button_toggled));

  // Синхронизация состояния изображения в виджете m_Area_Lines с состоянием кнопки-переключателя.
  on_button_toggled();

  show_all_children();
}

ExampleWindow::~ExampleWindow()
{
}

void ExampleWindow::on_button_toggled()
{
  m_Area_Lines.fix_lines(m_Button_FixLines.get_active());
}
