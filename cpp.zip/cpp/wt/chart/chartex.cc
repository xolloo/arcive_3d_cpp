/*
 * Created by Dmitriy Amelchenko on 04.12.2021.
*/


#include "chartex.h"
#include "chartconf.h"
#include "csvutils.h"
#include <cmath>
#include <fstream>
#include <any>
#include <Wt/WStandardItem.h>
#include <Wt/WStandardItemModel.h>
#include <Wt/WText.h>
#include <Wt/WApplication.h>
#include <Wt/WTableView.h>
#include <Wt/WEnvironment.h>
#include <Wt/WItemDelegate.h>
#include <Wt/Chart/WCartesianChart.h>
#include <Wt/WDate.h>
#include <Wt/Chart/WPieChart.h>
//#include <Wt/WBorderLayout.h>
//#include <Wt/WFitLayout.h>
#include <array>

namespace {
  class NumericItem
      : public Wt::WStandardItem {
      public:
      std::unique_ptr<Wt::WStandardItem> clone() const override;

      void setData(const std::any &data, Wt::ItemDataRole role = Wt::ItemDataRole::User);
  };
  void NumericItem::setData(const std::any &data, Wt::ItemDataRole role) {
      std::any dt;
      if (role == Wt::ItemDataRole::Edit) {
          std::string s = Wt::asString(data).toUTF8();
          char *endptr;
          double d = strtod(s.c_str(), &endptr);
          if (*endptr == 0) {
              dt = std::any(d);
          } else {
              dt = data;
          }
      }
      Wt::WStandardItem::setData(data, role);
  }
  std::unique_ptr<Wt::WStandardItem> NumericItem::clone() const {
      return std::make_unique<NumericItem>();
  }

  std::shared_ptr<Wt::WStandardItemModel> readCsvFile(
      const std::string &filename,
      Wt::WContainerWidget *parent) {
      std::shared_ptr<Wt::WStandardItemModel>
          model = std::make_shared<Wt::WStandardItemModel>(0, 0);
      std::unique_ptr<NumericItem> prototype = std::make_unique<NumericItem>();
      model->setItemPrototype(std::move(prototype));
      std::ifstream file(filename.c_str());
      if (file) {
          csv::readFromCsv(file, model.get());
          for (int row = 0; row < model->rowCount(); ++row) {
              for (int col = 0; col < model->columnCount(); ++col) {
                  model->item(row, col);
              }
          }
          return model;
      }
      Wt::WString error(Wt::WString::tr("error-missing-data"));
      error.arg(filename, Wt::CharEncoding::UTF8);
      parent->addWidget(std::make_unique<Wt::WText>(error));
      return nullptr;
  }
}

ChartEx::ChartEx() : Wt::WContainerWidget() {
    this->addWidget(std::make_unique<Wt::WText>(Wt::WString::tr("introduction")));
    this->addWidget(std::make_unique<CategoryEx>());
    this->addWidget(std::make_unique<TimeSeriesEx>());
    this->addWidget(std::make_unique<ScatterPlotEx>());
    this->addWidget(std::make_unique<PieEx>());
}

CategoryEx::CategoryEx() : Wt::WContainerWidget() {
    this->addWidget(std::make_unique<Wt::WText>(Wt::WString::tr("category chart")));
    std::shared_ptr<Wt::WAbstractItemModel>
        model = readCsvFile(Wt::WApplication::appRoot() + "category.csv", this);
    if (!model) {
        throw; /*return;*/
    }
    auto wrap = this->addWidget(std::make_unique<Wt::WContainerWidget>());
    auto table = wrap->addWidget(std::make_unique<Wt::WTableView>());

    table->setMargin(10, Wt::Side::Top | Wt::Side::Bottom);
    table->setMargin(Wt::WLength::Auto, Wt::Side::Left | Wt::Side::Right);

    table->setModel(model);
    table->setSortingEnabled(true);
    table->setColumnResizeEnabled(true);
    table->setAlternatingRowColors(true);
    table->setColumnAlignment(0, Wt::AlignmentFlag::Center);
    table->setHeaderAlignment(0, Wt::AlignmentFlag::Center);
    table->setRowHeight(22);

    if (Wt::WApplication::instance()->environment().ajax()) {
        table->resize(600, 20 + 5 * 22);
        table->setEditTriggers(Wt::EditTrigger::SingleClicked);
    } else {
        table->resize(600, Wt::WLength::Auto);
        table->setEditTriggers(Wt::EditTrigger::None);
    }

    std::shared_ptr<Wt::WItemDelegate> delegate = std::make_shared<Wt::WItemDelegate>();
    delegate->setTextFormat("%.f");
    table->setItemDelegate(delegate);

    table->setColumnWidth(0, 80);
    for (size_t i = 1; i < model->columnCount(); ++i) {
        table->setColumnWidth(1, 120);
    }

    auto chart = this->addWidget(std::make_unique<Wt::Chart::WCartesianChart>());
    chart->setModel(model);
    chart->setXSeriesColumn(0);
    chart->setLegendEnabled(true);
    chart->setZoomEnabled(true);
    chart->setPanEnabled(true);
    chart->setAutoLayoutEnabled(true);
    chart->setBackground(Wt::WColor(200, 200, 200));

    for (size_t i = 1; i < model->columnCount(); ++i) {
        auto s = std::make_unique<Wt::Chart::WDataSeries>(i, Wt::Chart::SeriesType::Bar);
        s->setShadow(Wt::WShadow(3, 3, Wt::WColor(0, 0, 0, 127), 3));
        chart->addSeries(std::move(s));
    }

    chart->resize(800, 400);
    chart->setMargin(10, Wt::Side::Top | Wt::Side::Bottom);
    chart->setMargin(Wt::WLength::Auto, Wt::Side::Left | Wt::Side::Right);

    this->addWidget(std::make_unique<ChartConf>(chart));
}

TimeSeriesEx::TimeSeriesEx() : Wt::WContainerWidget() {
    this->addWidget(std::make_unique<Wt::WText>(Wt::WString::tr("scatter plot")));
    auto model = readCsvFile(Wt::WApplication::appRoot() + "timeseries.csv", this);
    if (!model) {
        throw; /*return;*/
    }
    for (int i = 0; i < model->rowCount(); ++i) {
        Wt::WString s = Wt::asString(model->data(i, 0));
        Wt::WDate d = Wt::WDate::fromString(s, "dd/MM/yy");
        model->setData(i, 0, d);
    }

    auto wrap = this->addWidget(std::make_unique<Wt::WContainerWidget>());
    auto table = wrap->addWidget(std::make_unique<Wt::WTableView>());

    table->setMargin(10, Wt::Side::Top | Wt::Side::Bottom);
    table->setMargin(Wt::WLength::Auto, Wt::Side::Left | Wt::Side::Right);

    table->setModel(model);
    table->setSortingEnabled(false);
    table->setColumnResizeEnabled(true);
    table->setSelectionMode(Wt::SelectionMode::None);
    table->setAlternatingRowColors(true);
    table->setColumnAlignment(0, Wt::AlignmentFlag::Center);
    table->setHeaderAlignment(0, Wt::AlignmentFlag::Center);
    table->setRowHeight(22);

    if (Wt::WApplication::instance()->environment().ajax()) {
        table->resize(800, 20 + 5 * 22);
        table->setEditTriggers(Wt::EditTrigger::SingleClicked);
    } else {
        table->resize(800, 20 + 5 * 22 + 25);
        table->setEditTriggers(Wt::EditTrigger::None);
    }

    auto delegate = std::make_shared<Wt::WItemDelegate>();
    delegate->setTextFormat("%.1f");
    table->setItemDelegate(delegate);

    auto delegateColumn = std::make_shared<Wt::WItemDelegate>();
    table->setItemDelegateForColumn(0, delegateColumn);

    table->setColumnWidth(0, 80);
    for (int i = 0; i < model->columnCount(); ++i) {
        table->setColumnWidth(i, 90);
    }

    auto chart = this->addWidget(std::make_unique<Wt::Chart::WCartesianChart>());
    chart->setModel(model);
    chart->setXSeriesColumn(0);
    chart->setLegendEnabled(true);
    chart->setZoomEnabled(true);
    chart->setPanEnabled(true);
    chart->setType(Wt::Chart::ChartType::Scatter);
    chart->axis(Wt::Chart::Axis::X).setScale(Wt::Chart::AxisScale::Date);
    chart->setAutoLayoutEnabled(true);
    chart->setBackground(Wt::WColor(200, 200, 200));

    for (int i = 1; i < 3; ++i) {
        auto s = std::make_unique<Wt::Chart::WDataSeries>(i, Wt::Chart::SeriesType::Line);
        s->setShadow(Wt::WShadow(3, 3, Wt::WColor(0, 0, 0, 127), 3));
        chart->addSeries(std::move(s));
    }

    chart->resize(800, 400);
    chart->setMargin(10, Wt::Side::Top | Wt::Side::Bottom);
    chart->setMargin(Wt::WLength::Auto, Wt::Side::Left | Wt::Side::Right);
    this->addWidget(std::make_unique<ChartConf>(chart));
}

ScatterPlotEx::ScatterPlotEx() : Wt::WContainerWidget() {
    this->addWidget(std::make_unique<Wt::WText>(Wt::WString::tr("scatter plot 2")));
    auto model = std::make_shared<Wt::WStandardItemModel>(40, 2);
    auto prototype = std::make_unique<NumericItem>();
    model->setItemPrototype(std::move(prototype));
    model->setHeaderData(0, Wt::WString("X"));
    model->setHeaderData(1, Wt::WString("Y = sin(X)"));

    for (size_t i = 0; i < 40; ++i) {
        double x = (static_cast<double >(i) - 20) / 4;
        model->setData(i, 0, x);
        model->setData(i, 1, sin(x));
    }

    auto chart = this->addWidget(std::make_unique<Wt::Chart::WCartesianChart>());
    chart->setModel(model);
    chart->setXSeriesColumn(0);
    chart->setLegendEnabled(true);
    chart->setZoomEnabled(true);
    chart->setPanEnabled(true);
    chart->setCrosshairEnabled(true);
    chart->setBackground(Wt::WColor(200, 200, 200));
    chart->setType(Wt::Chart::ChartType::Scatter);
    chart->axis(Wt::Chart::Axis::X).setLocation(Wt::Chart::AxisValue::Zero);
    chart->axis(Wt::Chart::Axis::Y).setLocation(Wt::Chart::AxisValue::Zero);
    chart->setAutoLayoutEnabled(true);

    auto s = std::make_unique<Wt::Chart::WDataSeries>(1, Wt::Chart::SeriesType::Curve);
    s->setShadow(Wt::WShadow(3, 3, Wt::WColor(0, 0, 0, 127), 3));
    chart->addSeries(std::move(s));
    chart->resize(800, 300);
    chart->setMargin(10, Wt::Side::Top | Wt::Side::Bottom);
    chart->setMargin(Wt::WLength::Auto, Wt::Side::Left | Wt::Side::Right);

    auto config = this->addWidget(std::make_unique<ChartConf>(chart));
    config->setValueFill(Wt::Chart::FillRangeType::ZeroValue);
}

PieEx::PieEx() : Wt::WContainerWidget() {
    this->addWidget(std::make_unique<Wt::WText>(Wt::WString::tr("pie chart")));
    auto model = std::make_shared<Wt::WStandardItemModel>();
    auto prototype = std::make_unique<NumericItem>();
    model->setItemPrototype(std::move(prototype));
    model->insertColumns(model->columnCount(), 2);
    model->setHeaderData(0, Wt::WString("Item"));
    model->setHeaderData(1, Wt::WString("Sales"));
    model->insertRows(model->rowCount(), 6);

    std::array<Wt::WString, 6>
        s_values{"Blueberry", "Cherry", "Apple", "Boston Cream", "Other", "Vanilla Cream"};
    std::array<int, 6> i_values{120, 30, 260, 160, 40, 120};
    for (int row = 0; row < 6; ++row) {
        model->setData(row, 0, s_values[row]);
        model->setData(row, 1, i_values[row]);
    }

    for (int row = 0; row < model->rowCount(); ++row) {
        for (int col = 0; col < model->columnCount(); ++col) {
            model->item(row, col)->setFlags(Wt::ItemFlag::Selectable | Wt::ItemFlag::Editable);
        }
    }

    auto wrap = this->addWidget(std::make_unique<Wt::WContainerWidget>());
    auto table = wrap->addWidget(std::make_unique<Wt::WTableView>());

    table->setMargin(10, Wt::Side::Top | Wt::Side::Bottom);
    table->setMargin(Wt::WLength::Auto, Wt::Side::Left | Wt::Side::Right);
    table->setModel(model);
    table->setSortingEnabled(true);
    table->setColumnWidth(1, 100);
    table->setRowHeight(22);

    if (Wt::WApplication::instance()->environment().ajax()) {
        table->resize(150 + 100 + 14, 20 + 6 * 22);
        table->setEditTriggers(Wt::EditTrigger::SingleClicked);
    } else {
        table->resize(150 + 100 + 14, Wt::WLength::Auto);
        table->setEditTriggers(Wt::EditTrigger::None);
    }

    auto chart = this->addWidget(std::make_unique<Wt::Chart::WPieChart>());
    chart->setModel(model);
    chart->setLabelsColumn(0);
    chart->setDataColumn(1);
    chart->setDisplayLabels(
        Wt::Chart::LabelOption::Outside | Wt::Chart::LabelOption::TextLabel |
            Wt::Chart::LabelOption::TextPercentage);
    chart->setPerspectiveEnabled(true, 0.2);
    chart->setShadowEnabled(true);
    chart->setExplode(0, 0.3);
    chart->resize(800, 300);
    chart->setMargin(10, Wt::Side::Top | Wt::Side::Bottom);
    chart->setMargin(Wt::WLength::Auto, Wt::Side::Left | Wt::Side::Right);
}
















