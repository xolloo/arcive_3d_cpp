//
// Created by Dmitriy Amelchenko on 04.12.2021.
//

#include "csvutils.h"
#include <cstdlib>
#include <Wt/WAbstractItemModel.h>
#include <boost/tokenizer.hpp>
#include <any>

namespace {
  typedef boost::tokenizer<boost::escaped_list_separator<char>> CsvTokenizer;
}

namespace csv {

  void readFromCsv(
      std::istream &f, Wt::WAbstractItemModel *model, int numRows, bool firstLineIsHeaders) {
      int csvRow = 0;
      while (f) {
          std::string line;
          getline(f, line);

          if (f) {
              CsvTokenizer tok(line);
              int col = 0;
              for (CsvTokenizer::iterator i = tok.begin(); i != tok.end(); ++i, ++col) {
                  if (col >= model->columnCount()) {
                      model->insertColumns(model->columnCount(), col + 1 - model->columnCount());
                  }

                  if (firstLineIsHeaders && csvRow == 0) {
                      model->setHeaderData(col, std::any(Wt::WString(*i)));
                  } else {
                      int dataRow = firstLineIsHeaders ? csvRow - 1 : csvRow;
                      if (numRows != -1 && dataRow >= numRows) {
                          return;
                      }
                      if (dataRow >= model->rowCount()) {
                          model->insertColumns(model->rowCount(), dataRow + 1 - model->rowCount());
                      }
                      std::any data;
                      std::string s = *i;
                      char *endptr;

                      if (s.empty()) {
                          data = std::any();
                      } else {
                          double d = strtod(s.c_str(), &endptr);
                          if (*endptr == 0) {
                              data = std::any(d);
                          } else {
                              data = std::any(Wt::WString(s));
                          }
                      }
                      model->setData(dataRow, col, data);
                  }
              }
          }
          ++csvRow;
      }
  }
}