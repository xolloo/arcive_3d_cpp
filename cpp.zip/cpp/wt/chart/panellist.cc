//
// Created by Dmitriy Amelchenko on 05.12.2021.
//

#include "panellist.h"
#include <Wt/WPanel.h>

PanelList::PanelList() : Wt::WContainerWidget() {}
Wt::WPanel *PanelList::addWidget(const Wt::WString &text, std::unique_ptr<Wt::WWidget> widget) {
    auto p = std::make_unique<Wt::WPanel>();
    auto result = p.get();
    p->setTitle(text);
    p->setCentralWidget(std::move(widget));
    this->addPanel(std::move(p));
    return result;
}
void PanelList::addPanel(std::unique_ptr<Wt::WPanel> panel) {
    panel->setCollapsed(true);
    panel->collapse();
    panel->expandedSS().connect(
        std::bind(
            &PanelList::onExpand, this, std::placeholders::_1, panel.get()));
    Wt::WContainerWidget::addWidget(std::move(panel));
}
void PanelList::onExpand(bool notUndo, Wt::WPanel *panel) {
    if (notUndo) {
        this->wasExpanded_ = -1;
        for (size_t i = 0; i < this->children().size(); ++i) {
            Wt::WPanel *p = dynamic_cast<Wt::WPanel *>(this->children()[i]);
            if (p != panel) {
                if (!p->isCollapsed()) {
                    this->wasExpanded_ = i;
                }
                p->collapse();
            }
        }
    } else {
        if (this->wasExpanded_ != -1) {
            Wt::WPanel *p = dynamic_cast<Wt::WPanel *>(this->children()[this->wasExpanded_]);
            p->expand();
        }
    }
}

