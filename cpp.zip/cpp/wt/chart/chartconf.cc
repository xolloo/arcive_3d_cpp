//
// Created by Dmitriy Amelchenko on 04.12.2021.
//

#include "chartconf.h"
#include "panellist.h"
#include <iostream>
#include <string>
#include <any>
#include <Wt/WTable.h>
#include <Wt/WText.h>
#include <Wt/WString.h>
#include <Wt/WLineEdit.h>
#include <Wt/WLocale.h>
#include <Wt/WAbstractItemModel.h>
#include <Wt/Chart/WCartesianChart.h>
#include <Wt/WIntValidator.h>
#include <Wt/WDoubleValidator.h>
#include <Wt/WStandardItemModel.h>
#include <Wt/WComboBox.h>
#include <Wt/WCheckBox.h>

namespace {
  void addHeader(Wt::WTable *t, const char *value) {
      t->elementAt(0, t->columnCount())->addWidget(std::make_unique<Wt::WText>(value));
  }

  void addEntry(
      const std::shared_ptr<Wt::WAbstractItemModel> &
      model,
      const char *value
  ) {
      model->insertRows(model->rowCount(), 1);
      model->setData(model->rowCount() - 1, 0, std::any(std::string(value)));
  }

  void addEntry(const std::shared_ptr<Wt::WAbstractItemModel> &model, const Wt::WString &value) {
      model->insertRows(model->rowCount(), 1);
      model->setData(model->rowCount() - 1, 0, std::any(value));
  }

  bool getDouble(Wt::WLineEdit *edit, double &value) {
      try {
          value = Wt::WLocale::currentLocale().toDouble(edit->text());
          return true;
      }
      catch (...) {
          return false;
      }
  }

  int seriesIndexOf(Wt::Chart::WCartesianChart *chart, int modelColumn) {
      for (int i = 0; i < chart->series().size(); ++i) {
          if (chart->series()[i]->modelColumn() == modelColumn) {
              return i;
          }
      }
      return -1;
  }

  Wt::WString axisName(Wt::Chart::Axis axis, int axisId) {
      if (axis == Wt::Chart::Axis::X) {
          return Wt::utf8("X axis {1}").arg(axisId + 1);
      } else {
          return Wt::utf8("Y axis {1}").arg(axisId + 1);
      }
  }
}

ChartConf::ChartConf(Wt::Chart::WCartesianChart *chart)
    : Wt::WContainerWidget(),
    chart_(chart),
    fill_(Wt::Chart::FillRangeType::MinimumValue) {
    this->chart_->setLegendStyle(
        this->chart_->legendFont(), Wt::WPen(Wt::WColor("black")),
        Wt::WBrush(Wt::WColor(0xff, 0xfa, 0xe5)));
    auto list = this->addWidget(std::make_unique<PanelList>());

    auto sizeValidator = std::make_shared<Wt::WIntValidator>(200, 2000);
    sizeValidator->setMandatory(true);

    this->anyNumberValidator_ = std::make_shared<Wt::WDoubleValidator>();
    this->anyNumberValidator_->setMandatory(true);

    this->angleValidator_ = std::make_shared<Wt::WDoubleValidator>(-90, 90);
    this->angleValidator_->setMandatory(true);

    auto orientation = std::make_shared<Wt::WStandardItemModel>(0, 1);
    ::addEntry(orientation, "Vertical");
    ::addEntry(orientation, "Horizontal");

    auto legendLocation = std::make_shared<Wt::WStandardItemModel>(0, 1);
    ::addEntry(legendLocation, "Outside");
    ::addEntry(legendLocation, "Inside");

    auto legendSide = std::make_shared<Wt::WStandardItemModel>(0, 1);
    ::addEntry(legendSide, "Top");
    ::addEntry(legendSide, "Right");
    ::addEntry(legendSide, "Bottom");
    ::addEntry(legendSide, "Left");

    auto legendAlignment = std::make_shared<Wt::WStandardItemModel>(0, 1);
    ::addEntry(legendSide, "AlignTop");
    ::addEntry(legendSide, "AlignRight");
    ::addEntry(legendSide, "AlignBottom");
    ::addEntry(legendSide, "AlignLeft");
    ::addEntry(legendSide, "AlignCenter");
    ::addEntry(legendSide, "AlignMiddle");

    auto chartConfig = std::make_unique<Wt::WTable>();
    chartConfig->setMargin(Wt::WLength::Auto, Wt::Side::Left | Wt::Side::Right);

    int row = 0;

    chartConfig->elementAt(row, 0)->addWidget(std::make_unique<Wt::WText>("Title:"));
    this->titleEdit_ = chartConfig->elementAt(row, 1)->addWidget(std::make_unique<Wt::WLineEdit>());
    this->connectSignals(this->titleEdit_);
    ++row;

    chartConfig->elementAt(row, 0)->addWidget(std::make_unique<Wt::WText>("Width:"));
    this->chartWidthEdit_ = chartConfig->elementAt(row, 1)->addWidget
        (std::make_unique<Wt::WLineEdit>());
    this->chartWidthEdit_->setText(
        Wt::WLocale::currentLocale().toString(
            this->chart_->width()
                .value()));
    this->chartWidthEdit_->setValidator(sizeValidator);
    this->chartWidthEdit_->setMaxLength(4);
    this->connectSignals(this->chartWidthEdit_);
    ++row;

    chartConfig->elementAt(row, 0)->addWidget(std::make_unique<Wt::WText>("Height:"));
    this->chartHeigthEdit_ = chartConfig->elementAt(row, 1)->addWidget
        (std::make_unique<Wt::WLineEdit>());
    this->chartHeigthEdit_->setText(
        Wt::WLocale::currentLocale().toString(
            this->chart_->height()
                .value()));
    this->chartHeigthEdit_->setValidator(sizeValidator);
    this->chartHeigthEdit_->setMaxLength(4);
    this->connectSignals(this->chartHeigthEdit_);
    ++row;

    chartConfig->elementAt(row, 0)->addWidget(std::make_unique<Wt::WText>("Orientation:"));
    this->chartOrientationEdit_ = chartConfig->elementAt(row, 1)->addWidget
        (std::make_unique<Wt::WComboBox>());
    this->chartOrientationEdit_->setModel(orientation);
    this->chartOrientationEdit_->setCurrentIndex(0);
    this->connectSignals(this->chartOrientationEdit_);
    ++row;

    chartConfig->elementAt(row, 0)->addWidget(std::make_unique<Wt::WText>("Legend location:"));
    this->legendLocationEdit_ = chartConfig->elementAt(row, 1)->addWidget
        (std::make_unique<Wt::WComboBox>());
    this->legendLocationEdit_->setModel(legendLocation);
    this->legendLocationEdit_->setCurrentIndex(0);
    this->connectSignals(this->legendLocationEdit_);
    ++row;

    chartConfig->elementAt(row, 0)->addWidget(std::make_unique<Wt::WText>("Legend side:"));
    this->legendSideEdit_ = chartConfig->elementAt(row, 1)->addWidget
        (std::make_unique<Wt::WComboBox>());
    this->legendSideEdit_->setModel(legendSide);
    this->legendSideEdit_->setCurrentIndex(1);
    this->connectSignals(this->legendSideEdit_);
    ++row;

    chartConfig->elementAt(row, 0)->addWidget(std::make_unique<Wt::WText>("Legend align:"));
    this->legendAlignmentEdit_ = chartConfig->elementAt(row, 1)->addWidget
        (std::make_unique<Wt::WComboBox>());
    this->legendAlignmentEdit_->setModel(legendAlignment);
    this->legendAlignmentEdit_->setCurrentIndex(4);
    this->connectSignals(this->legendAlignmentEdit_);
    ++row;

    chartConfig->elementAt(row, 0)->addWidget(std::make_unique<Wt::WText>("Border:"));
    this->borderEdit_ = chartConfig->elementAt(row, 1)->addWidget
        (std::make_unique<Wt::WCheckBox>());
    this->borderEdit_->setChecked(false);
    this->connectSignals(this->borderEdit_);
    ++row;

    for (int i = 0; i < chartConfig->rowCount(); ++i) {
        chartConfig->elementAt(i, 0)->setStyleClass("tdhead");
        chartConfig->elementAt(i, 1)->setStyleClass("tddata");
    }

    auto p = list->addWidget("Chart properties", std::move(chartConfig));

//    p->setMargin(Wt::WLegend::AUTO, Wt::Side::Left | Wt::Side::Right);
}
