#include "chartex.h"
#include <Wt/WApplication.h>

class Chart
    : public Wt::WApplication {
    public:
    Chart() = delete;
    explicit Chart(const Wt::WEnvironment &env) : Wt::WApplication(env) {
        this->setTitle("Charts Example.");
        this->setCssTheme("polished");
        this->messageResourceBundle().use(Chart::appRoot() + "charts");
        this->root()->setPadding(10);
        this->root()->resize(Wt::WLength::Auto, Wt::WLength::Auto);
        this->root()->addWidget(std::make_unique<ChartEx>());
        this->useStyleSheet("charts.css");
    }
};

std::unique_ptr<Wt::WApplication> create_app(const Wt::WEnvironment &env) {
    return std::make_unique<Chart>(env);
}

int main(int argc, char **argv) {
    return Wt::WRun(argc, argv, &create_app);
}
