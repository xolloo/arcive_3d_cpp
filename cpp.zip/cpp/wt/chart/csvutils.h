//
// Created by Dmitriy Amelchenko on 04.12.2021.
//

#ifndef CHART__CSVUTILS_H
#define CHART__CSVUTILS_H

#include <iostream>
namespace Wt {
  class WAbstractItemModel;
}

namespace csv {
  extern void readFromCsv(
      std::istream &f,
      Wt::WAbstractItemModel *model,
      int numRows = -1, bool
      firstLineIsHeaders = true);
}

#endif //CHART__CSVUTILS_H
