//
// Created by Dmitriy Amelchenko on 05.12.2021.
//

#ifndef CHART__PANELLIST_H
#define CHART__PANELLIST_H

#include <Wt/WContainerWidget.h>

namespace Wt {
  class WPanel;
}

class PanelList
    : public Wt::WContainerWidget {
    private:
    void onExpand(bool notUndo, Wt::WPanel *panel);
    int wasExpanded_{};
    public:
    PanelList();
    Wt::WPanel *addWidget(const Wt::WString &text, std::unique_ptr<Wt::WWidget> widget);
    void addPanel(std::unique_ptr<Wt::WPanel> panel);
    void removePanel(Wt::WPanel *panel);

//    using WContainerWidget::addWidget;
};

#endif //CHART__PANELLIST_H
