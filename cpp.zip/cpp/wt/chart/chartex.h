/*
 * Created by Dmitriy Amelchenko on 04.12.2021.
*/


#ifndef CHART__CHARTEX_H
#define CHART__CHARTEX_H

#include <Wt/WContainerWidget.h>
#include <iostream>

namespace Wt {
  class WAbstractItemModel;

  namespace Ext {
    class TableView;
  }
}

class TimeSeriesEx
    : public Wt::WContainerWidget {
    public:
    TimeSeriesEx();
};

class CategoryEx
    : public Wt::WContainerWidget {
    public:
    CategoryEx();
};

class ScatterPlotEx
    : public Wt::WContainerWidget {
    public:
    ScatterPlotEx();
};

class PieEx
    : public Wt::WContainerWidget {
    public:
    PieEx();
};

class ChartEx
    : public Wt::WContainerWidget {
    public:
    ChartEx();
};

#endif //CHART__CHARTEX_H
