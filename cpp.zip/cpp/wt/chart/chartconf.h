/*
 * Created by Dmitriy Amelchenko on 04.12.2021.
*/


#ifndef CHART__CHARTCONF_H
#define CHART__CHARTCONF_H

#include <Wt/WContainerWidget.h>
#include <Wt/Chart/WDataSeries.h>

namespace Wt {
  class WCheckBox;
  class WComboBox;
  class WFormWidget;
  class WLineEdit;
  class WStandardItemModel;
  class WTable;
  class WValidator;

  namespace Chart {
    class WAxis;
    class WCartesianChart;
  }
}

class ChartConf
    : public Wt::WContainerWidget {
    private:
    Wt::Chart::WCartesianChart *chart_;
    Wt::Chart::FillRangeType fill_;
    struct SeriesControl {
        Wt::WCheckBox *enabledEdit;
        Wt::WComboBox *typeEdit;
        Wt::WComboBox *markerEdit;
        Wt::WComboBox *xAxisEdit;
        Wt::WComboBox *yAxisEdit;
        Wt::WCheckBox *legendEdit;
        Wt::WCheckBox *shadowEdit;
        Wt::WComboBox *labelsEdit;
    };
    std::vector<SeriesControl> seriesControls_;
    struct AxisControl {
        Wt::WCheckBox *visibleEdit;
        Wt::WComboBox *scaleEdit;
        Wt::WCheckBox *autoEdit;
        Wt::WLineEdit *minimumEdit;
        Wt::WLineEdit *maximumEdit;
        Wt::WCheckBox *gridLinesEdit;
        Wt::WLineEdit *lineAngleEdit;
        Wt::WLineEdit *titleEdit;
        Wt::WComboBox *titleOrientationEdit;
        Wt::WComboBox *titleDirectionEdit;
        Wt::WComboBox *locationEdit;
    };
    std::vector<AxisControl> axisControls_;
    Wt::WLineEdit *titleEdit_;
    Wt::WLineEdit *chartWidthEdit_;
    Wt::WLineEdit *chartHeigthEdit_;
    Wt::WComboBox *chartOrientationEdit_;
    Wt::WComboBox *legendLocationEdit_;
    Wt::WComboBox *legendSideEdit_;
    Wt::WComboBox *legendAlignmentEdit_;
    Wt::WCheckBox *borderEdit_;
    std::shared_ptr<Wt::WStandardItemModel> xAxesModel_, yAxesModel_, xScales_, yScales_;
    std::shared_ptr<Wt::WValidator> anyNumberValidator_, angleValidator_;
    Wt::WTable *axisConfig_;
    void connectSignals(Wt::WFormWidget *form);
    void update();
    void addXAxis();
    void addYAxis();
    void addAxis(Wt::Chart::Axis axis, int axisId);
    void removeXAxis(const Wt::Chart::WAxis *axis);
    void removeYAxis(const Wt::Chart::WAxis *axis);
    void clearXAxis();
    void clearYAxis();
    static bool validate(Wt::WFormWidget);

    public:
    ChartConf(Wt::Chart::WCartesianChart *chart);
    void setValueFill(Wt::Chart::FillRangeType fill);

};

#endif //CHART__CHARTCONF_H
