#include <Wt/WApplication.h>
#include <Wt/WEnvironment.h>
#include <Wt/WDialog.h>

class HelloApp
    : public Wt::WApplication {
    public:
    explicit HelloApp(const Wt::WEnvironment &env)
        : Wt::WApplication(env),
        m_dialog(std::make_unique<Wt::WDialog>("Hello")) {
        this->setTitle("Hello world");
        this->root()->addWidget(std::move(this->m_dialog));
    }
    HelloApp() = delete;
    private:
    std::unique_ptr<Wt::WDialog> m_dialog;
};

int main(int argc, char **argv) {
    return Wt::WRun(
        argc, argv, [](const Wt::WEnvironment &env) {
            return std::make_unique<HelloApp>(env);
        });
}
