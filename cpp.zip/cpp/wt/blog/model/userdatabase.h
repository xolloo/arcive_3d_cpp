/*
 * Created by Dmitriy Amelchenko on 09.12.2021.
*/


#ifndef WT_BLOG_MODEL_USERDATABASE_H
#define WT_BLOG_MODEL_USERDATABASE_H

#include <Wt/Auth/AbstractUserDatabase.h>
#include <Wt/Dbo/Types.h>

class User;

class UserDatabase
    : public Wt::Auth::AbstractUserDatabase {
    private:
    Wt::Dbo::Session &session_;
    mutable Wt::Dbo::ptr<User> user_;

    struct WithUser {
        WithUser(const UserDatabase &self, const Wt::Auth::User &user);
        ~WithUser();
        Wt::Dbo::Transaction transaction;
    };

    void getUser(const std::string &id) const;

};

#endif //WT_BLOG_MODEL_USERDATABASE_H
