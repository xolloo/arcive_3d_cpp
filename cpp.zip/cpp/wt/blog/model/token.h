/*
 * Created by Dmitriy Amelchenko on 09.12.2021.
*/


#ifndef WT_BLOG_MODEL_TOKEN_H
#define WT_BLOG_MODEL_TOKEN_H

#include <string>
#include <Wt/WDate.h>
#include <Wt/Dbo/Types.h>
#include <Wt/Dbo/WtSqlTraits.h>

class User;

class Token
    : public Wt::Dbo::Dbo<Token> {
    public:
    Token() = default;
    Token(std::string &, Wt::WDateTime &);
    Wt::Dbo::ptr<User> user;

    std::string value;
    Wt::WDateTime expires;

    template<class Action>
    void persist(Action &a) {
        Wt::Dbo::field(a, value, "value");
        Wt::Dbo::field(a, expires, "expires");
        Wt::Dbo::belongsTo(a, user, "user");
    }
};

DBO_EXTERN_TEMPLATES(Token)

#endif //WT_BLOG_MODEL_TOKEN_H
