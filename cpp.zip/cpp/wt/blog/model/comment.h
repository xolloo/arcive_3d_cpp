/*
 * Created by Dmitriy Amelchenko on 09.12.2021.
*/


#ifndef WT_BLOG_MODEL_COMMENT_H
#define WT_BLOG_MODEL_COMMENT_H

#include <Wt/WString.h>
#include <Wt/WDateTime.h>
#include <Wt/Dbo/Types.h>
#include <Wt/Dbo/WtSqlTraits.h>

class Comment;
class Post;
class User;

typedef Wt::Dbo::collection<Wt::Dbo::ptr<Comment>> Comments;

class Comment {
    public:
    Comment() = default;
    Wt::Dbo::ptr<User> author;
    Wt::Dbo::ptr<Post> post;
    Wt::Dbo::ptr<Comment> parent;
    Wt::WDateTime date;
    Comments children;

    void setText(Wt::WString &);
    void setDeleted();
    [[nodiscard]] const Wt::WString &textSrc() const { return this->textSrc_; };
    [[nodiscard]] const Wt::WString &textHtml() const { return this->textHtml_; };

    template<class Action>
    void persist(Action &a) {
        Wt::Dbo::field(a, date, "date");
        Wt::Dbo::field(a, textSrc_, "text_source");
        Wt::Dbo::field(a, textHtml_, "text_html");
        Wt::Dbo::belongsTo(a, author, "author");
        Wt::Dbo::belongsTo(a, post, "post", Wt::Dbo::OnDeleteCascade);
        Wt::Dbo::belongsTo(a, parent, "parent", Wt::Dbo::OnDeleteCascade);
        Wt::Dbo::hasMany(a, children, Wt::Dbo::ManyToOne, "parent");
    }

    private:
    Wt::WString textSrc_;
    Wt::WString textHtml_;
};

DBO_EXTERN_TEMPLATES(Comment)

#endif //WT_BLOG_MODEL_COMMENT_H
