/*
 * Created by Dmitriy Amelchenko on 09.12.2021.
*/


#include "tag.h"
#include <Wt/Dbo/Impl.h>

#include <utility>

DBO_INSTANTIATE_TEMPLATES(Tag)

Tag::Tag(std::string aName) : name(std::move(aName)) {}
//Tag::Tag(std::string &aName) : name(aName) {}
