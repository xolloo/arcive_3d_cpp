/*
 * Created by Dmitriy Amelchenko on 09.12.2021.
*/


#ifndef WT_BLOG_MODEL_USER_H
#define WT_BLOG_MODEL_USER_H

#include "token.h"
#include "post.h"
#include <Wt/WString.h>
#include <Wt/WDateTime.h>
#include <Wt/Dbo/Types.h>
#include <string>

class Comment;

typedef Wt::Dbo::collection<Wt::Dbo::ptr<Comment>> Comments;
typedef Wt::Dbo::collection<Wt::Dbo::ptr<Post>> Posts;
typedef Wt::Dbo::collection<Wt::Dbo::ptr<Token>> Tokens;

class User {
    public:
    enum Role {
        Visitor = 0,
        Admin = 1
    };
    User();
    explicit User(User::Role);
    Wt::WString name;
    Role role;
    std::string password;
    std::string passMethod;
    std::string passSalt;
    int failedLoginAttempts;
    Wt::WDateTime lastLoginAttempt;

    std::string oAuthId;
    std::string oAuthProvider;

    Tokens authToken;
    Comments comments;
    Posts posts;

    Posts latestPosts(int count = 10) const;
    Posts allPosts(Post::State state, int count = 10) const;

    template<class Action>
    void persist(Action &a) {
        Wt::Dbo::field(a, name, "name");
        Wt::Dbo::field(a, password, "password");
        Wt::Dbo::field(a, passMethod, "password_method");
        Wt::Dbo::field(a, passSalt, "password_salt");
        Wt::Dbo::field(a, role, "role");
        Wt::Dbo::field(a, failedLoginAttempts, "failed_login_attempts");
        Wt::Dbo::field(a, lastLoginAttempt, "last_login_attempt");
        Wt::Dbo::field(a, oAuthId, "o_auth_id");
        Wt::Dbo::field(a, oAuthProvider, "o_auth_provider");
        Wt::Dbo::field(a, comments, Wt::Dbo::ManyToOne, "author"); /*?*/
        Wt::Dbo::field(a, posts, Wt::Dbo::ManyToOne, "author");
        Wt::Dbo::field(a, authToken, Wt::Dbo::ManyToOne, "user");
    }

    static Wt::Dbo::dbo_traits<User>::IdType stringToId(std::string &);
};

DBO_EXTERN_TEMPLATES(User);

#endif //WT_BLOG_MODEL_USER_H
