/*
 * Created by Dmitriy Amelchenko on 09.12.2021.
*/


#include "post.h"
#include "user.h"
#include<sstream>
#include <cctype>
#include <Wt/Dbo/Impl.h>

DBO_INSTANTIATE_TEMPLATES(Post)

std::string Post::permaLink() const {
    return this->date.toString("yyyy/MM/dd'" + this->titleToUrl() + '\'').toUTF8();
}

std::string Post::commentCount() const {
    size_t count = this->comments.size();
    std::stringstream ss;
    ss << count << " comments";
    return ss.str();
}

Wt::Dbo::ptr<Comment> Post::rootComment() const {
    if (this->session()) {
        return this->session()->find<Comment>()
                   .where("post_id = ?")
                   .bind(this->id())
                   .where("parent_id is null");
    }
    return {};
}
std::string Post::titleToUrl() const {
    std::string result = this->title.narrow();
    for (char &i: result)
        i = !isalnum(i) ? '_' : static_cast<char>(tolower(i));
    return result;
}
