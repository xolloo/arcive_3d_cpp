/*
 * Created by Dmitriy Amelchenko on 09.12.2021.
*/


#include "token.h"
#include "user.h"
#include <Wt/Dbo/Impl.h>

DBO_INSTANTIATE_TEMPLATES(Token)

Token::Token(std::string &value, Wt::WDateTime &explict)
    : value(value),
    expires(explict) {}
