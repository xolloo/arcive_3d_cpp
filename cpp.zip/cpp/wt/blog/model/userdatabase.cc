/*
 * Created by Dmitriy Amelchenko on 09.12.2021.
*/


#include "userdatabase.h"
#include "user.h"
#include <string>
#include <exception>

class InvalidUser
    : public std::runtime_error {
    public:
    InvalidUser(const std::string &message) : std::runtime_error("Invalid user: " + message) {}
};

