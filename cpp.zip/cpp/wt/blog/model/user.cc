/*
 * Created by Dmitriy Amelchenko on 09.12.2021.
*/


#include "user.h"
#include "post.h"
#include "token.h"
#include "comment.h"
#include <string>
#include <Wt/Dbo/Impl.h>
//#include "tag.h" /*?*/

DBO_INSTANTIATE_TEMPLATES(User)

User::User() : role(Visitor), failedLoginAttempts(0) {}

User::User(User::Role role) : role(role), failedLoginAttempts(0) {}

Posts User::latestPosts(int count) const {
    return posts.find().where("state = ?")
                .bind(Post::Published)
                .orderBy("date desc")
                .limit(count);
}

Posts User::allPosts(Post::State state, int count) const {
    return posts.find().where("state = ?")
                .bind(state)
                .orderBy("date desc")
                .limit(count);
}
Wt::Dbo::dbo_traits<User>::IdType User::stringToId(std::string &s) {
    std::size_t pos = std::string::npos;
    auto result = std::stoll(s, &pos);
    if (pos == s.size()) {
        return result;
    }
    return Wt::Dbo::dbo_traits<User>::invalidId();
}

