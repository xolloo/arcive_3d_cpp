/*
 * Created by Dmitriy Amelchenko on 09.12.2021.
*/


#ifndef WT_BLOG_MODEL_TAG_H
#define WT_BLOG_MODEL_TAG_H

#include <Wt/Dbo/Types.h>

class Post;
typedef Wt::Dbo::collection<Wt::Dbo::ptr<Post>> Posts;

class Tag {
    public:
    Tag() = default;
    explicit Tag(std::string );
//    explicit Tag(std::string &);
    std::string name;
    Posts posts;

    template<class Action>
    void persist(Action &a) {
        Wt::Dbo::field(a, name, "name");
        Wt::Dbo::hasMany(a, posts, Wt::Dbo::ManyToMany, "post_tag");
    }
};

DBO_EXTERN_TEMPLATES(Tag)

#endif //WT_BLOG_MODEL_TAG_H
