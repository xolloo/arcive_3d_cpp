/*
 * Created by Dmitriy Amelchenko on 09.12.2021.
*/


#ifndef WT_BLOG_MODEL_POST_H
#define WT_BLOG_MODEL_POST_H

#include "comment.h"
#include "tag.h"
#include <string>
#include <Wt/WString.h>
#include <Wt/WDateTime.h>
#include <Wt/Dbo/Types.h>
#include <Wt/Dbo/WtSqlTraits.h>

class User;

typedef Wt::Dbo::collection<Wt::Dbo::ptr<Comment>> Comments;
typedef Wt::Dbo::collection<Wt::Dbo::ptr<Tag>> Tags;

class Post
    : public Wt::Dbo::Dbo<Post> {
    public:
    enum State {
        Unpublished = 0,
        Published = 1
    };

    Wt::Dbo::ptr<User> author;
    State state;

    Wt::WDateTime date;
    Wt::WString title;
    Wt::WString briefSrc;
    Wt::WString briefHtml;
    Wt::WString bodySrc;
    Wt::WString bodyHtml;

    Comments comments;
    Tags tags;

    [[nodiscard]] std::string permaLink() const;
    [[nodiscard]] std::string commentCount() const;
    [[nodiscard]] Wt::Dbo::ptr<Comment> rootComment() const;
    [[nodiscard]] std::string titleToUrl() const;

    template<class Action>
    void persist(Action &a) {
        Wt::Dbo::field(a, state, "state");
        Wt::Dbo::field(a, date, "date");
        Wt::Dbo::field(a, title, "title");
        Wt::Dbo::field(a, briefSrc, "briefSrc");
        Wt::Dbo::field(a, briefHtml, "briefHtml");
        Wt::Dbo::field(a, bodySrc, "body_src");
        Wt::Dbo::field(a, bodyHtml, "body_html");
        Wt::Dbo::field(a, author, "author");
        Wt::Dbo::field(a, comments, Wt::Dbo::ManyToOne, "post");
        Wt::Dbo::field(a, tags, Wt::Dbo::ManyToMany, "post_tag");
    }
};

DBO_EXTERN_TEMPLATES(Post)

#endif //WT_BLOG_MODEL_POST_H
