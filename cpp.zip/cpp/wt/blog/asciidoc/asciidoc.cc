/*
 * Created by Dmitriy Amelchenko on 08.12.2021.
*/

#include "asciidoc.h"
#include <string>
#include <fstream>
#include <csignal>
#include <unistd.h>
#include <Wt/WString.h>

namespace {
  std::string tempFileName() {
      char spool[] = "/tmp/wtXXXXXX";
      int i = mkstemp(spool);
      close(i);
      return {spool};
  }

  std::string readFileToString(const std::string &fileName) {
      std::fstream file(fileName.c_str(), std::ios::in | std::ios::binary | std::ios::ate);
      ssize_t length = file.tellg();
      file.seekg(0, std::ios::beg);

      std::unique_ptr<char[]> buf(new char[length]);
      file.read(buf.get(), length);
      file.close();
      return {buf.get()};
  }
}

Wt::WString asciidoc(const Wt::WString &src) {
    std::string srcFileName = ::tempFileName();
    std::string htmlFileName = ::tempFileName();

    {
        std::ofstream srcFile(srcFileName.c_str(), std::ios::out);
        std::string ssrc = src.toUTF8();
        srcFile.write(ssrc.c_str(), (std::streamsize) ssrc.length());
        srcFile.close();
    }

    std::string cmd = "asciidoc";
    std::string command = cmd + " -o " + htmlFileName + " -s " + srcFileName;
    struct sigaction newAction{}, oldAction{};
    newAction.sa_handler = SIG_IGN;
    newAction.sa_flags = 0;
    sigemptyset(&newAction.sa_mask);
    sigaction(SIGINT, &newAction, &oldAction);
    bool ok = system(command.c_str()) == 0;
    sigaction(SIGINT, &oldAction, nullptr);

    Wt::WString result;
    if (ok) {
        result = Wt::WString(readFileToString(htmlFileName));
    } else {
        result = Wt::WString("<i>Could not execute asciidoc</i>");
    }

    unlink(srcFileName.c_str());
    unlink(htmlFileName.c_str());

    return result;
}
