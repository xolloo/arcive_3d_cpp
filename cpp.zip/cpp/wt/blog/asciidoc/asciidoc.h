/*
 * Created by Dmitriy Amelchenko on 08.12.2021.
*/


#ifndef WT_BLOG_ASCIIDOC_ASCIIDOC_H
#define WT_BLOG_ASCIIDOC_ASCIIDOC_H

namespace Wt {
  class WString;
}

extern Wt::WString asciidoc(const Wt::WString &);

#endif //WT_BLOG_ASCIIDOC_ASCIIDOC_H
