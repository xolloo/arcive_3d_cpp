//
// Created by Dmitriy Amelchenko on 04.12.2021.
//

#include "helloworld.h"
//#include <Wt/WContainerWidget.h>
#include <Wt/WBreak.h>
#include <Wt/WPushButton.h>
#include <iostream>

HelloWorld::HelloWorld(const Wt::WEnvironment &env) : Wt::WApplication(env) {
    this->setTitle("Hello world");
    auto page = this->root();
    page->addWidget(std::make_unique<Wt::WText>("Your name, please?"));
    this->nameEdit_ = page->addWidget(std::make_unique<Wt::WLineEdit>());
    this->nameEdit_->setFocus();
    auto button = page->addWidget(std::make_unique<Wt::WPushButton>("Great me."));
    button->setMargin(5, Wt::Side::Left);
    page->addWidget(std::make_unique<Wt::WText>());
    this->greeting_ = page->addWidget(std::make_unique<Wt::WText>());
    button->clicked().connect(this, &HelloWorld::greet);
    this->nameEdit_->enterPressed().connect(std::bind(&HelloWorld::greet, this));
    button->clicked().connect(
        [=]() {
            std::cerr << "Hello there, " << this->nameEdit_->text() << std::endl;
        });
}
void HelloWorld::greet() {
    this->greeting_->setText("Hello there, " + this->nameEdit_->text());
}


