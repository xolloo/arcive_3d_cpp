//
// Created by Dmitriy Amelchenko on 04.12.2021.
//

#ifndef WT_EXAMPLE__HELLOWORLD_H
#define WT_EXAMPLE__HELLOWORLD_H

#include <Wt/WApplication.h>
#include <Wt/WLineEdit.h>
#include <Wt/WText.h>

class HelloWorld
    : public Wt::WApplication {
    private:
    Wt::WLineEdit *nameEdit_;
    Wt::WText *greeting_;
    void greet();
    public:
    HelloWorld() = delete;
    HelloWorld(const Wt::WEnvironment &env);
};

#endif //WT_EXAMPLE__HELLOWORLD_H
