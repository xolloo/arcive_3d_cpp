//
// Created by hacker on 11.03.19.
//

#include "gwindow.h"
#include <gtkmm/stock.h>
//#include <gwindow.h>

#include <iostream>

#define BORDER_WIDTH 5
#define PADDING_WIDTH 3
#define PADDING_HEIGHT 3
#define WIDTH 800
#define HEIGHT 600


GWindow::GWindow() :
    energy(0),
    is_work(false),
    am_space(Gtk::ALIGN_FILL, Gtk::ALIGN_END, 0, 0),
    bx_master(Gtk::ORIENTATION_HORIZONTAL),
    bx_left(Gtk::ORIENTATION_VERTICAL),
    bx_right(Gtk::ORIENTATION_VERTICAL),
    bb_exit_apply(Gtk::ORIENTATION_HORIZONTAL),
    lb_count_bots("0"),
    lb_generation("0"),
    lb_age("0"),
    bt_on_off(Gtk::Stock::EXECUTE),
    bt_apply(Gtk::Stock::APPLY),
    bt_close(Gtk::Stock::CLOSE),
    aj_energy(Gtk::Adjustment::create(0.0, 0.0, 1000.0, 10.0, 50.0, 0.0)),
    sb_energy(aj_energy)
{

//    this->fullscreen();
    this->maximize();
//    this->set_resizable(false);
    this->set_title("Genom");
    this->set_size_request(WIDTH, HEIGHT);

    this->add(this->bx_master);
    this->bx_master.set_border_width(BORDER_WIDTH);
    this->bx_master.pack_start(this->bx_left, Gtk::PACK_EXPAND_WIDGET, 0);

    this->bx_left.pack_start(this->canvas, Gtk::PACK_EXPAND_WIDGET);

    this->bx_master.add(this->bx_right);
    this->bx_right.set_border_width(BORDER_WIDTH);
    this->bx_right.pack_start(this->bt_on_off, Gtk::PACK_SHRINK, BORDER_WIDTH);

    this->bx_right.pack_start(this->fr_count_bots, Gtk::PACK_SHRINK, BORDER_WIDTH);
    this->fr_count_bots.set_label("Count bots");
    this->fr_count_bots.set_shadow_type(Gtk::SHADOW_ETCHED_IN);
    this->fr_count_bots.set_label_align(Gtk::ALIGN_CENTER, Gtk::ALIGN_END);
    this->fr_count_bots.add(this->lb_count_bots);
    this->lb_count_bots.set_padding(PADDING_WIDTH, PADDING_HEIGHT);

    this->bx_right.pack_start(this->fr_generation, Gtk::PACK_SHRINK, BORDER_WIDTH);
    this->fr_generation.set_label("Ceneration");
    this->fr_generation.set_shadow_type(Gtk::SHADOW_ETCHED_IN);
    this->fr_generation.set_label_align(Gtk::ALIGN_CENTER, Gtk::ALIGN_END);
    this->fr_generation.add(this->lb_generation);
    this->lb_generation.set_padding(PADDING_WIDTH, PADDING_WIDTH);

    this->bx_right.pack_start(this->fr_age, Gtk::PACK_SHRINK, BORDER_WIDTH);
    this->fr_age.set_label("Ceneration");
    this->fr_age.set_shadow_type(Gtk::SHADOW_ETCHED_IN);
    this->fr_age.set_label_align(Gtk::ALIGN_CENTER, Gtk::ALIGN_END);
    this->fr_age.add(this->lb_age);
    this->lb_age.set_padding(PADDING_WIDTH, PADDING_WIDTH);

    this->bx_right.pack_start(this->am_space, Gtk::PACK_EXPAND_WIDGET, BORDER_WIDTH);

    this->bx_right.pack_start(this->fr_energy, Gtk::PACK_SHRINK, BORDER_WIDTH);
    this->fr_energy.set_label("Energy");
    this->fr_energy.set_shadow_type(Gtk::SHADOW_ETCHED_IN);
    this->fr_energy.set_label_align(Gtk::ALIGN_CENTER, Gtk::ALIGN_END);
    this->fr_energy.add(this->sb_energy);

    this->bx_right.pack_start(this->bb_exit_apply, Gtk::PACK_SHRINK, BORDER_WIDTH);
    this->bb_exit_apply.add(this->bt_apply);
    this->bb_exit_apply.add(this->bt_close);
    this->bt_apply.set_sensitive(false);

    this->bt_on_off.signal_clicked().connect(
            sigc::mem_fun(*this, &GWindow::on_toggle_work)
            );
    this->sb_energy.signal_changed().connect(
            sigc::mem_fun(*this, &GWindow::on_change_energy)
            );
    this->bt_apply.signal_clicked().connect(
            sigc::mem_fun(*this, &GWindow::on_apply_energy)
            );
    this->bt_close.signal_clicked().connect(
            sigc::mem_fun(*this, &GWindow::on_close)
            );

    this->show_all();
}

GWindow::~GWindow() {}

void GWindow::on_close() {
    this->hide();
}

void GWindow::on_toggle_work() {
    this->bt_on_off.set_label(this->is_work ? "Cancel" : "Execute");
    this->is_work = !this->is_work;
}

void GWindow::on_change_energy() {
    this->bt_apply.set_sensitive(this->sb_energy.get_value() == this->energy ? false : true);
}

void GWindow::on_apply_energy() {
    this->energy = static_cast<unsigned short>(this->sb_energy.get_value());
    this->bt_apply.set_sensitive(false);
}


