//
// Created by hacker on 11.03.19.
//
#include "canvas.h"
#include <iostream>
//#include <chrono>
//#include <thread>
//#include <cmath>
//#include <glibmm/main.h>
//#include <random>

Canvas::Canvas() {
    this->color["red"] = {1.0, 0.0, 0.0};
    this->color["pink"] = {1.0, 0.75, 0.79};
    this->color["orange"] = {1.0, 0.632, 0.0};
    this->color["lime"] = {0.0, 1.0, 0.0};
    this->color["blue"] = {0.0, 0.0, 1.0};
    for (int i = 0; i < ROW * COL; ++i) {
        this->arr[i].width = this->step - this->lint_width;
        this->arr[i].height = this->step - this->lint_width;
    }
    for (int i = 0; i < ROW; ++i) {
        for (int j = 0; j < COL; ++j) {
            this->arr[i+j+((COL-1)*i)].x = i + this->lint_width;
            this->arr[i+j+((COL-1)*i)].y = j + this->lint_width;
            this->arr[i+j+((COL-1)*i)].color = this->color["pink"];
        }
    }
    this->arr[100].color = this->color["red"];
    this->arr[500].color = this->color["orange"];
    this->arr[1100].color = this->color["lime"];
    this->arr[2200].color = this->color["blue"];
}

Canvas::~Canvas() {

}

bool Canvas::on_draw(const Cairo::RefPtr<Cairo::Context> &cr) {
    std::cout << "on_draw()\n";
    Gtk::Allocation allocation;
    allocation = this->get_allocation();
    this->width = allocation.get_width();
    this->height = allocation.get_height();
    cr->set_line_width(this->lint_width);
    cr->set_source_rgb(
            this->color["pink"].R,
            this->color["pink"].G,
            this->color["pink"].B
            );
    for (int i = this->lint_width; (i + step) <= this->width; i += this->step) {
        for (int j = this->lint_width; (j + step) <= this->height; j += this->step) {
            cr->move_to(i, j);
            cr->rectangle(
                    i, j,
                    this->step - (this->lint_width),
                    this->step - (this->lint_width)
            );
        }
    }
    cr->fill();

    cr->move_to(this->arr[100].x, this->arr[100].y);
    cr->rectangle(
            this->arr[100].x,
            this->arr[100].y,
            this->arr[100].width,
            this->arr[100].height
            );
    cr->set_source_rgb(
            this->arr[100].color.R,
            this->arr[100].color.G,
            this->arr[100].color.B
            );
    cr->fill();

    cr->move_to(this->arr[500].x, this->arr[500].y);
    cr->rectangle(
            this->arr[500].x,
            this->arr[500].y,
            this->arr[500].width,
            this->arr[500].height
            );
    cr->set_source_rgb(
            this->arr[500].color.R,
            this->arr[500].color.G,
            this->arr[500].color.B
    );
    cr->fill();

    cr->move_to(this->arr[1100].x, this->arr[1100].y);
    cr->rectangle(
            this->arr[1100].x,
            this->arr[1100].y,
            this->arr[1100].width,
            this->arr[1100].height
    );
    cr->set_source_rgb(
            this->arr[1100].color.R,
            this->arr[1100].color.G,
            this->arr[1100].color.B
    );
    cr->fill();

    cr->move_to(this->arr[2200].x, this->arr[2200].y);
    cr->rectangle(
            this->arr[2200].x,
            this->arr[2200].y,
            this->arr[2200].width,
            this->arr[2200].height
    );
    cr->set_source_rgb(
            this->arr[2200].color.R,
            this->arr[2200].color.G,
            this->arr[2200].color.B
    );
    cr->fill();

    cr->set_source_rgb(0.8, 0.0, 0.0);
    cr->stroke();
    return true;
}

//bool Canvas::on_timeout() {
//    Glib::RefPtr<Gdk::Window> win = this->get_window();
//    if (win) {
//        Gdk::Rectangle r(
//                0, 0,
//                this->get_allocation().get_width(),
//                this->get_allocation().get_height()
//        );
//        win->invalidate_rect(r, false);
//    }
//
//    return true;
//}