#include "gwindow.h"
#include <gtkmm/application.h>

int main(int argc, char** argv)
{
    auto app = Gtk::Application::create("org.gtkmm.example");
    GWindow win;
    return app->run(win, argc, argv);
}