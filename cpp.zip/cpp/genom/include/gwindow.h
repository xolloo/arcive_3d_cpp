//
// Created by hacker on 11.03.19.
//

#ifndef GENOM_GWINDOW_H
#define GENOM_GWINDOW_H

#include <gtkmm/window.h>
#include <gtkmm/alignment.h>
#include <gtkmm/frame.h>
#include <gtkmm/box.h>
#include <gtkmm/buttonbox.h>
#include <gtkmm/label.h>
#include <gtkmm/button.h>
#include <gtkmm/adjustment.h>
#include <gtkmm/spinbutton.h>
#include "canvas.h"

class GWindow : public Gtk::Window
{
public:
    GWindow();
    virtual ~GWindow();
    void on_change_energy();
    void on_apply_energy();
    void on_close();
    void on_toggle_work();
protected:
    unsigned short energy;
    bool is_work;
    Canvas canvas;
    Gtk::Alignment am_space;
    Gtk::Box bx_master;
    Gtk::Box bx_left;
    Gtk::Box bx_right;
    Gtk::Frame fr_count_bots;
    Gtk::Frame fr_generation;
    Gtk::Frame fr_age;
    Gtk::Frame fr_energy;
    Gtk::ButtonBox bb_exit_apply;
    Gtk::Label lb_count_bots;
    Gtk::Label lb_generation;
    Gtk::Label lb_age;
    Gtk::Button bt_on_off;
    Gtk::Button bt_apply;
    Gtk::Button bt_close;
    Glib::RefPtr<Gtk::Adjustment> aj_energy;
    Gtk::SpinButton sb_energy;
};

#endif //GENOM_GWINDOW_H
