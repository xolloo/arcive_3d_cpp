//
// Created by hacker on 11.03.19.
//

#ifndef GENOM_CANVAS_H
#define GENOM_CANVAS_H

#include <gtkmm/drawingarea.h>
#include <cairomm/context.h>
//#include <vector>
#include <array>
#include <map>

#define ROW 214
#define COL 346

class Canvas : public Gtk::DrawingArea
{
public:
    Canvas();
    virtual ~Canvas();

protected:
    virtual bool on_draw(const Cairo::RefPtr<Cairo::Context>& cr);
//    bool on_timeout();
    struct Color {
        float R;
        float G;
        float B;
    };
    std::map<Glib::ustring, Color> color;
    struct Rect {
        unsigned short x;
        unsigned short y;
        unsigned short width;
        unsigned short height;
        Color color;
    };
    std::array<Rect, ROW*COL> arr;

    double lint_width = 0.2;
    unsigned short step = 5;
    unsigned short width;
    unsigned short height;

};

#endif //GENOM_CANVAS_H
