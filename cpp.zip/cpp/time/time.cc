#include <thread>
#include <functional>
#include <mutex>
#include <condition_variable>
#include <iostream>

class Timer
{
private:
    void wait_then_call()
    {
        std::unique_lock<std::mutex> lck(this->mtx);
        this->cv.wait_for(lck, time);
        this->func();
    }
    std::mutex mtx;
    std::condition_variable cv;
    std::chrono::seconds time;
    std::function<void(void)> func;
    std::thread wait_thread{[this]()
                            { this->wait_then_call(); }};

public:
    Timer(size_t time, std::function<void(void)> &f,) : time(std::chrono::seconds(time)), func(f){}
    ~Timer() { this->wait_thread.join(); }
};

class Func
{
private:
    size_t num;

public:
    Func() : num(1){};
    Func(size_t n) : num(n) {}
    void operator()()
    {
        std::cout << "____ I wait to print! ____: ";
        std::cout << this->num << '\n';
    }
};

class timeout
{
private:
    std::mutex mtx;
    size_t t_val;
    size_t i_val;
    std::function<void(void)> func;
    timeout();

public:
    timeout(const std::function<void(void)> f, size_t interval) : func(f), i_val(interval), t_val(10){};
    ~timeout(){};
    void set()
    {
        Timer t(this->t_val, this->func);
    }
    void wait()
    {
        // ожидать завершение
    }
};

int main()
{
    // Timer t1(10000000, std::move(worker(1)));
    // Timer t2(4000000, std::move(worker(2)));
    timeout t1(std::move(Func(1)), 1);
    t1.set();
    return 0;
}