/*
#include "clock.h"
#include <gtkmm/application.h>
#include <gtkmm/window.h>

int main(int argc, char** argv)
{
   Glib::RefPtr<Gtk::Application> app = Gtk::Application::create(argc, argv, "org.gtkmm.example");

   Gtk::Window win;
   win.set_title("Часы на основе cairomm");

   Clock c;
   win.add(c);
   c.show();

   return app->run(win);
}
*/

#include "dndwindow.h"
#include <gtkmm/application.h>

int main (int argc, char *argv[])
{
	Glib::RefPtr<Gtk::Application> app = Gtk::Application::create(
				argc, argv, "org.gtkmm.example");

	DnDWindow dndWindow;
	return app->run(dndWindow);
}
