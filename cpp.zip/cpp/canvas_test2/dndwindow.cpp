#include "dndwindow.h"
#include <iostream>

DnDWindow::DnDWindow() :
	m_Button_Drag("Захватывайте\nданные здесь"),
	m_Label_Drop("Перемещайте\nданные сюда")
{
	this->set_title("Механизм захвата и перемещения");
	this->add(m_HBox);
	std::vector<Gtk::TargetEntry> listTargets;
	listTargets.push_back(Gtk::TargetEntry("STRING"));
	listTargets.push_back(Gtk::TargetEntry("text/plain"));

	this->m_Button_Drag.drag_source_set(listTargets);
	this->m_Button_Drag.signal_drag_data_get().connect(
				sigc::mem_fun(*this, &DnDWindow::on_button_drag_data_get));

	this->m_HBox.pack_start(this->m_Button_Drag);

	this->m_Label_Drop.drag_dest_set(listTargets);
	this->m_Label_Drop.signal_drag_data_received().connect(
				sigc::mem_fun(*this, &DnDWindow::on_label_drop_drag_data_received));
	this->m_HBox.pack_start(this->m_Label_Drop);
	this->show_all();
}

DnDWindow::~DnDWindow(){}

void DnDWindow::on_button_drag_data_get(
		const Glib::RefPtr<Gdk::DragContext> &context,
		Gtk::SelectionData &selection_data, guint info, guint time)
{
	selection_data.set(
				selection_data.get_target(), 8,
				(const guchar*)"I'm Data!", 9);
}

void DnDWindow::on_label_drop_drag_data_received(
		const Glib::RefPtr<Gdk::DragContext> &context, int x, int y,
		const Gtk::SelectionData &selection_data, guint info, guint time)
{
	const int length = selection_data.get_length();
	if (length >= 0 && (selection_data.get_format() == 8))
	{
		std::cout << "Принят текст \"" << selection_data.get_data_as_string()
				  << "\" с помощью виджета вывода строки " << std::endl;
	}

	context->drag_finish(false, false, time);
}
