#include "myarea.h"
#include <cairomm/context.h>

MyArea::MyArea(){}
MyArea::~MyArea(){}
bool MyArea::on_draw(const Cairo::RefPtr<Cairo::Context> &cr)
{
	Gtk::Allocation allocation = this->get_allocation();
	int width = allocation.get_width();
	int height = allocation.get_height();
	int lesser = MIN(width, height);

	int xc, yc;
	xc = width / 2;
	yc = height / 2;

//	cr->set_line_width(lesser * 0.02);
//	cr->save();
//	cr->arc(width / 3.0, height / 4.0,
//			lesser / 4.0, -(M_PI / 5.0), M_PI);
//	cr->close_path();
//	cr->set_source_rgb(0.0, 0.8, 0.0);
//	cr->fill_preserve();
//	cr->restore();
//	cr->stroke();

//	cr->save();
//	cr->arc(xc, yc, lesser / 4.0, 2 * M_PI_4, 2.0 * M_PI);
//	cr->set_source_rgba(0.0, 0.0, 0.8, 0.6);
//	cr->fill_preserve();
//	cr->restore();
//	cr->stroke();

	double ex, ey, ew, eh;
	ex = xc;
	ey = 3.0 * height / 4.0;
	ew = 3.0 * width / 4.0;
	eh = height	/ 3.0;

	cr->save();

	cr->translate(ex, ey);
	cr->scale(ew / 2.0, eh / 2.0);

	cr->arc(0.0, 0.0, 1.0, 0.0, 2 * M_PI);
	cr->set_source_rgba(0.8, 0.0, 0.0, 0.7);
	cr->fill_preserve();
	cr->restore();
	cr->stroke();

	return true;
}
