#include <stdio.h>
#include <string.h>
#include <stdint.h>
#include <stdbool.h>

int main()
{
	uint_fast8_t value = 0;
	value |= (7<<4);
	value |= (3<<0);
	for (uint_fast8_t i = 8; i > 0; --i) {
		printf("%d", (value >> (i-1)) & 1);
	}
	printf("\n");
//	value |= (1<<4);
//	value |= (5<<0);
//	for (uint_fast8_t i = 8; i > 0; --i) {
//		printf("%d", (value >> (i-1)) & 1);
//	}
//	printf("\n");

	int test[3][5] = {0};
	for (int i=0; i<3; ++i) {
		for (int j=0; j<5; ++j) {
			printf("%d ", test[i][j]);
		}
		printf("\n");
	}
	return 0;
}
