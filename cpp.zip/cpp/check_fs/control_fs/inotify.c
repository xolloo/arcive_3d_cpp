#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <sys/select.h>
#include <sys/inotify.h>
#include <signal.h>

#include "queue.h"
#include "utils.h"

int keep_running;

void signal_handler (int signum)
{
    keep_running = 0;
}

int main (int argc, char** argv)
{
    int inotify_fd;
    keep_running = 1;
    if (signal (SIGINT, signal_handler) == SIG_IGN)
    {
        signal (SIGINT, SIG_IGN);
    }
    inotify_fd = open_inotify_fd ();
    if (inotify_fd > 0)
    {
        queue_t q = queue_create ();
        int wd = 0;
        printf ("\n");
        for(int index = 1; (index < argc) && (wd >= 0); ++index)
        {
            wd = watch_dir (inotify_fd, argv[index], IN_ALL_EVENTS);
        }
        if (wd > 0)
        {
            process_inotify_events (q, inotify_fd);
        }
        printf ("\nTerminated\n");
        close_inotify_fd(inotify_fd);
        queue_destroy(q);
    }
    return 0;
}
