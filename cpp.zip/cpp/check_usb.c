#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/poll.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <linux/types.h>
#include <linux/netlink.h>

void error(char *s)
{
    write(2, s, strlen(s));
    exit(1);
}

int main(int argc, char** argv)
{
    struct sockaddr_nl netlink_socket;
    struct pollfd poll_fd;
    char buf[512];

    memset(&netlink_socket, 0, sizeof(struct sockaddr_nl));
    netlink_socket.nl_family = AF_NETLINK;
    netlink_socket.nl_pid = getpid();
    netlink_socket.nl_groups = -1;

    poll_fd.events = POLLIN;
    poll_fd.fd = socket(PF_NETLINK, SOCK_DGRAM, NETLINK_KOBJECT_UEVENT);
    if (poll_fd.fd == -1)
    {
        error("Not root\n");
    }
    if (bind(poll_fd.fd, (void*)&netlink_socket, sizeof(struct sockaddr_nl)))
    {
        error("Bind failed\n");
    }

    while (-1 != poll(&poll_fd, 1, -1))
    {
        int i = 0;
        int len = recv(poll_fd.fd, buf, sizeof(buf), MSG_DONTWAIT);
        if (len == -1)
        {
            error("Recv failed\n");
        }
        while (i < len)
        {
            printf("%s\n", (buf + i));
            i += strlen(buf + i) + 1;
        }
    }
    error("Poll close\n");
    return 0;
}
