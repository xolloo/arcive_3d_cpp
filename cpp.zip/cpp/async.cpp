#include <iostream>
#include <string>
#include <future>
#include <thread>
#include <chrono>

int main()
{
	std::cout << "Main thread id=" <<std::this_thread::get_id() << '\n';
	auto asyncDefault = std::async([]()
	{
		std::cout << "Async defautl, Thread id="
				  << std::this_thread::get_id()
				  << '\n';
		throw std::bad_alloc();
	});

	auto asyncDeffered = std::async(std::launch::deferred, [](const std::string& str)
	{
		std::cout << "Async deffer, Thread id="
				  << std::this_thread::get_id()
				  << ',' << str << '\n';
	}, std::string("end string"));

	auto asyncDeffered2 = std::async(std::launch::deferred, []()
	{
		std::cout << "Async deffer2, Thread id="
				  << std::this_thread::get_id()
				  << '\n';
	});

	auto trueAsync = std::async(std::launch::async, []()
	{
		std::cout << "True async, Thread id="
				  << std::this_thread::get_id()
				  << '\n';
		throw std::bad_alloc();
	});

	std::this_thread::sleep_for(std::chrono::seconds(5));
	std::cout << "Sleep ended\n";
	try
	{
		asyncDefault.get();
	}
	catch (std::exception& err)
	{
		std::cout << "Error: " << err.what() << '\n';
	}
	asyncDeffered.get();
	asyncDeffered2.get();
	try
	{
		trueAsync.get();
	}
	catch (std::exception& err)
	{
		std::cout << "Error 2: " << err.what() << '\n';
	}
	return 0;
}
